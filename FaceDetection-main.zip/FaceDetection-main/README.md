# Face Detection and Recognition
The aim of this project is to create a computer application and train a model which will detect and recognizes the face of a human from images as well as videos and shows the output in text format on the screen.

READ AND SHOW VIDEO STREAM , AND THEN CAPTURE IMAGES .

DETECT THE FACES AND SHOW BOUNDING BOX .

FLATTEN THE LARGEST FACE IMAGE AND SAVE IN A NUMPY ARRAY.

REPEAT THE ABOVE FOR MULTIPLE PEOPLE TO GENERATE THE TRAINING DATA .

LOAD THE TRAINING DATA (NUMPY ARRAYS OF ALL THE PERSONS ).

USED KNN TO FIND THE PREDICTION OF FACES (INT).

MAP THE PREDICTED ID TO THE NAME OF THE USER .

DISPLAY THE PREDICATIONS ON THE SCREEN - BOUNDING BOX AND NAME

